package org.com.virtusa.exception;

public class InputStringException extends Throwable {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


private String message;


  private Throwable exception;
  
  /** Constructor for the InputStringException object */
  public InputStringException() {
    this.message = "";
  }
  
  public InputStringException(String msg) {
    this.message= msg;
  }

  public String getMessage() {
  
    return message;
  }

  
  public void setMessage(String message) {
  
    this.message = message;
  }

  
  public Throwable getException() {
  
    return exception;
  }

  
  public void setException(Throwable exception) {
  
    this.exception = exception;
  }

}
