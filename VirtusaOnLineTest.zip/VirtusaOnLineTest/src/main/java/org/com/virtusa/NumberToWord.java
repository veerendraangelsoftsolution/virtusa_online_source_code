
package org.com.virtusa;
import java.util.Scanner;

import org.com.virtusa.exception.InputStringException;

public class NumberToWord {
  
  public static void main(String args[]){
    System.out.println("PROGRAM STARTS from HERE, Write Exit in case you want to EXIT from Application \n\n\n\n");
   
    while(true){
      System.out.print("\n\n\nPlease Enter the Number :");
      String inputNumberString =  taking_Input_from_User();
      
      ConvertNumberToWords(inputNumberString);
         
    } 
  }
  
  public static void ConvertNumberToWords(String inputNumberString){
    String validInputString = null;
    check_for_valid_input(inputNumberString);
    validInputString = ifValidRemoveAllPreceeding(inputNumberString) ;
    System.out.println("Your Number is == "+validInputString);
    
    System.out.println("Your Number is == "+validInputString.length());
    
    int noOfMillion = Integer.valueOf(validInputString)/1000000;
    int noOfThousand = (Integer.valueOf(validInputString)%1000000)/1000;
    int restPart =  (Integer.valueOf(validInputString)%1000000)%1000;
    if(noOfMillion>0){
      ConvertThreeDigitNumberTowWords.convert(String.valueOf(noOfMillion).toCharArray());System.out.print(" Million, ");
    }
    if(noOfThousand>0){
      ConvertThreeDigitNumberTowWords.convert(String.valueOf(noOfThousand).toCharArray());System.out.print(" Thousand, ");
    }
    ConvertThreeDigitNumberTowWords.convert(String.valueOf(restPart).toCharArray());
    
  }
 
  public static String taking_Input_from_User(){
    Scanner in = new Scanner(System.in);
    String s = in.nextLine().trim();
    
   
    if("EXIT".equalsIgnoreCase(s)){
      System.out.println("Thanks for Using the Application, Have a Great Day ");
      System.exit(0);
    }
    
    return s;
    
  }
  
 public static String check_for_valid_input(String inputNumberString){
    
    if(isNullOrEmptyString(inputNumberString)){
      try {
        throw new InputStringException("null or Empty value not Allowed");
      }
      catch (InputStringException e) {
        e.printStackTrace();
      }
    }
    
    if(!isValidIntegerValue(inputNumberString)){
      try {
        throw new InputStringException("Not a Valid Integer");
      }
      catch (InputStringException e) {
        e.printStackTrace();
      }
    }
    
    
    return inputNumberString;
    
 }
 // Checking for Null or Empty Value
 public static boolean isNullOrEmptyString(String inputNumberString){
   boolean isNullOrEmptyValue=false;
   if(inputNumberString==null || "".equals(inputNumberString)){
     isNullOrEmptyValue = true;
   }
   return isNullOrEmptyValue;
 }
 
 // Not a valid Integer
 public static boolean isValidIntegerValue(String inputNumberString){
   boolean isValid=true;
   try{
   Integer.valueOf(inputNumberString);
   }catch(Exception e){
     isValid=false;
   }
   return isValid;
 }
 
 public static String ifValidRemoveAllPreceeding(String inputNumberString){
   
   while(inputNumberString.startsWith("0")){
     inputNumberString =  inputNumberString.replaceFirst("0", "");
   }
   return inputNumberString;
 }
    
  }
  

